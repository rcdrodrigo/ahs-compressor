# app/main.py -- versión 2.0 (con libCST)

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import json
import traceback
from typing import Any, Dict

# Importar nuestros módulos refactorizados
from ahs_compressor.encoder import AHSEncoderFull, encode_python
from ahs_compressor.decoder import decode_ahs, decode_python, validate_roundtrip

app = FastAPI(
    title="AHS-Compressor v2", 
    version="2.0",
    description="Compresor de código Python usando libCST para preservación de formato."
)

# Middleware CORS para desarrollo
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Cambiar en producción
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modelos Pydantic
class AHSPayload(BaseModel):
    ahs: str = Field(..., description="La estructura AHS en formato JSON string.")
    map: str = Field(..., description="El mapa de código en formato JSON string.")

class CodePayload(BaseModel):
    code: str

class CompressResponse(BaseModel):
    ahs: Any = Field(..., description="La estructura AHS como un objeto JSON.")
    map: Dict[str, str] = Field(..., description="El mapa de código de referencia.")
    original_size: int
    compressed_size: int
    compression_ratio: float

# Endpoints

@app.get("/")
async def root():
    return {"message": "AHS-Compressor API v2.0", "status": "running"}

@app.post("/compress-text", response_model=CompressResponse)
async def compress_text(payload: CodePayload):
    """
    Comprime un fragmento de código Python a formato AHS v2.
    """
    try:
        src = payload.code
        if not src.strip():
            raise HTTPException(status_code=400, detail="El código no puede estar vacío.")
        
        result = encode_python(src)
        ahs_obj = json.loads(result["ahs"])
        map_obj = json.loads(result["map"])
        
        original_size = len(src)
        compressed_size = len(result["ahs"]) + len(result["map"])
        ratio = compressed_size / original_size if original_size > 0 else 0
        
        return CompressResponse(
            ahs=ahs_obj,
            map=map_obj,
            original_size=original_size,
            compressed_size=compressed_size,
            compression_ratio=ratio
        )
        
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Error de compresión: {str(e)}")

@app.post("/decompress-text", response_model=CodePayload)
async def decompress_text(payload: AHSPayload):
    """
    Descomprime formato AHS v2 de vuelta a código Python.
    """
    try:
        code = decode_ahs(payload.ahs, payload.map)
        return CodePayload(code=code)
        
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Error de descompresión: {str(e)}")

@app.get("/health")
async def health_check():
    return {"status": "healthy", "version": "2.0"}

if __name__ == "__main__":
    import uvicorn
    print("Iniciando servidor Uvicorn en http://localhost:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)
