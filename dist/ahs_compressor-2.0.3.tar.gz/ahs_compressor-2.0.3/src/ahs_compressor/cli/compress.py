# cli/compress.py -- versión 2.0

import argparse
import sys
import os
import json
from pathlib import Path

# La línea sys.path.insert ya no es necesaria con el empaquetado correcto.

from ahs_compressor.encoder import encode_python
from ahs_compressor.decoder import decode_ahs

def process_directory(dir_path: Path) -> dict:
    """Procesa un directorio recursivamente y genera un AHS y mapa combinados."""
    project_ahs = {"type": "Project", "name": dir_path.name, "children": []}
    project_map = {}

    for root, _, files in os.walk(dir_path):
        for file in files:
            if file.endswith('.py'):
                file_path = Path(root) / file
                relative_path = file_path.relative_to(dir_path)
                print(f"Procesando: {relative_path}", file=sys.stderr)
                
                with open(file_path, 'r', encoding='utf-8') as f:
                    source_code = f.read()
                
                # Codificar el archivo
                result = encode_python(source_code)
                file_ahs = json.loads(result['ahs'])
                file_map = json.loads(result['map'])
                
                # Añadir al AHS del proyecto
                project_ahs["children"].append({
                    "type": "File",
                    "name": str(relative_path),
                    "children": file_ahs
                })
                
                # Fusionar el mapa de código
                project_map.update(file_map)

    return {"ahs": json.dumps(project_ahs, indent=2), "map": json.dumps(project_map, indent=2)}

def main():
    parser = argparse.ArgumentParser(
        description="Comprime o descomprime código Python con AHS v2.",
        epilog="Ejemplo (directorio): python cli/compress.py encode ./mi_proyecto -o proj.json\n" \
               "Ejemplo (fichero): python cli/compress.py decode proj.json -o ./mi_proyecto_restaurado"
    )
    
    parser.add_argument("action", choices=["encode", "decode"], help="Acción a realizar")
    parser.add_argument("path", help="Ruta al directorio o fichero de entrada")
    parser.add_argument("-o", "--output", required=True, help="Ruta al fichero de salida")
    
    args = parser.parse_args()
    
    if args.action == "encode":
        input_path = Path(args.path)
        if not input_path.exists():
            print(f"Error: La ruta de entrada no existe: {args.path}", file=sys.stderr)
            sys.exit(1)

        if input_path.is_dir():
            result = process_directory(input_path)
        elif input_path.is_file() and input_path.suffix == '.py':
            with open(input_path, 'r', encoding='utf-8') as f:
                result = encode_python(f.read())
        else:
            print("Error: Para 'encode', la entrada debe ser un directorio o un fichero .py", file=sys.stderr)
            sys.exit(1)
        
        with open(args.output, 'w', encoding='utf-8') as f:
            # Escribir un solo JSON que contenga tanto el AHS como el mapa
            final_output = {
                "ahs": json.loads(result["ahs"]),
                "map": json.loads(result["map"])
            }
            json.dump(final_output, f, indent=2)
        print(f"Proyecto codificado en: {args.output}", file=sys.stderr)

    elif args.action == "decode":
        input_path = Path(args.path)
        if not input_path.is_file():
            print(f"Error: Para 'decode', la entrada debe ser un fichero JSON.", file=sys.stderr)
            sys.exit(1)

        output_path = Path(args.output)
        output_path.mkdir(parents=True, exist_ok=True)

        with open(input_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        ahs_data = data["ahs"]
        code_map = data["map"]

        # Asumimos que el AHS es de un proyecto
        for file_node in ahs_data.get("children", []):
            if file_node["type"] == "File":
                file_rel_path = Path(file_node["name"])
                file_abs_path = output_path / file_rel_path
                file_abs_path.parent.mkdir(parents=True, exist_ok=True)

                # Reconstruir el AHS y mapa solo para este archivo
                file_ahs_json = json.dumps(file_node["children"])
                
                print(f"Restaurando: {file_abs_path}", file=sys.stderr)
                restored_code = decode_ahs(file_ahs_json, json.dumps(code_map))
                
                with open(file_abs_path, 'w', encoding='utf-8') as f_out:
                    f_out.write(restored_code)
        print(f"Proyecto restaurado en: {args.output}", file=sys.stderr)

if __name__ == "__main__":
    main()
